Version 4
SymbolType BLOCK
LINE Normal -48 -32 -64 -32
LINE Normal -32 -16 -48 -32
LINE Normal 32 -16 -32 -16
LINE Normal 48 -32 32 -16
LINE Normal 64 -32 48 -32
LINE Normal -48 32 -64 32
LINE Normal -32 16 -48 32
LINE Normal 32 16 -32 16
LINE Normal 48 32 32 16
LINE Normal 64 32 48 32
LINE Normal -26 -10 -32 -16
LINE Normal 26 -10 -26 -10
LINE Normal 32 -16 26 -10
LINE Normal -26 10 -32 16
LINE Normal 26 10 -26 10
LINE Normal 32 16 26 10
WINDOW 39 1 45 Center 2
WINDOW 0 -2 -46 Top 2
SYMATTR SpiceLine Zo=50 Ze=50 To=1n Te=1n
SYMATTR Prefix X
SYMATTR Value diff_tline
SYMATTR Description Loseless Differential Transmission Line
PIN -64 -32 NONE 8
PINATTR PinName IN+
PINATTR SpiceOrder 1
PIN -64 32 NONE 8
PINATTR PinName IN-
PINATTR SpiceOrder 2
PIN 64 -32 NONE 8
PINATTR PinName OUT+
PINATTR SpiceOrder 3
PIN 64 32 NONE 8
PINATTR PinName OUT-
PINATTR SpiceOrder 4
